// script.js

document.addEventListener("DOMContentLoaded", function() {
    // تخزين التحديات الخاصة بكل يوم
    const challenges = {};

    // التحديات الافتراضية (لليوم 1 إلى 30)
    const defaultChallenges = [
        "رياضة ",
        " فيتأمين C ",
        "قرائة "
    ];

    const tableBody = document.querySelector("#challenges-table tbody");

    // إنشاء التحديات لكل يوم
    for (let i = 1; i <= 30; i++) {
        challenges[i] = [...defaultChallenges];  // نسخ التحديات الافتراضية لكل يوم

        const row = document.createElement("tr");

        const dayCell = document.createElement("td");
        dayCell.textContent = `اليوم ${i}`;
        row.appendChild(dayCell);

        // إضافة التحديات لهذا اليوم
        for (let j = 0; j < challenges[i].length; j++) {
            const challengeCell = document.createElement("td");

            const challengeText = document.createElement("span");
            challengeText.textContent = challenges[i][j];
            challengeCell.appendChild(challengeText);

            // إضافة زر الإنجاز
            const button = document.createElement("button");
            button.textContent = "إنجاز";
            button.onclick = function() {
                button.classList.add("completed");
                button.textContent = "تم الإنجاز";

                // إنشاء وتنسيق الوقت والتاريخ
                const date = new Date();
                const statusCell = document.createElement("div");
                statusCell.classList.add("status");
                statusCell.innerHTML = `تم في: <span>${date.toLocaleDateString()} - ${date.toLocaleTimeString()}</span>`;
                challengeCell.appendChild(statusCell);
            };

            challengeCell.appendChild(button);
            row.appendChild(challengeCell);
        }

        tableBody.appendChild(row);
    }
});
